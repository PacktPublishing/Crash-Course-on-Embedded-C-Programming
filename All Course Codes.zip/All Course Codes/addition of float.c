#include<stdio.h>
void main()
{
    float a, b , c;
    a = 5.8;
    b = 7.4;
    c = a + b;
    printf("This is my trial with C Coding\n");
    printf("Addition of %f + %f = %f\n\n",a,b,c);
}
