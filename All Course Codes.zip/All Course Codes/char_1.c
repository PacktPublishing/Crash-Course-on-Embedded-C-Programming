void main()
{
    char a;
    printf("\nEnter a character\n");
    scanf("%c",&a);
    //a = 'Z';
    printf("\nNow lets try printing the char\n");
    printf("\nLetter is %c\n",a);
    printf("\nASCII of that letter is %d\n",a);
}
