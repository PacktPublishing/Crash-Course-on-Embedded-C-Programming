#include<stdio.h>
void main()
{
    unsigned int a,b,c;  // signed char
                // SIGN
    a = 165534;
    b = 1;
    c = a + b + 1;
    printf("%d + %d = %d",a,b,c);
}
