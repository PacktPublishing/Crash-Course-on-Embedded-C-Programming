void main()
{
    char a;
    printf("\nEnter a character\n");
    a = getchar();
    //a = 'Z';
    printf("\nNow lets try printing the char\n");
    putchar(a);
}
