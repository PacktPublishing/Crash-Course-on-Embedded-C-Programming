#include<stdio.h>
void main()
{
    int a, b , c;
    a = 58;
    b = 74;
    c = a + b;
    printf("This is my trial with C Coding\n");
    printf("Addition of %d + %d = %d\n\n",c,b,a);
}
