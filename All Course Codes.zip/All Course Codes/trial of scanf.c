#include<stdio.h>
void main()
{
    int a,b,c;
    printf("Enter value of a = ");
    scanf("%d", &a);

    printf("\nEnter value of b = ");
    scanf("%d", &b);

    c = a + b;
    printf("\n%d + %d = %d\n",a,b,c);


}
