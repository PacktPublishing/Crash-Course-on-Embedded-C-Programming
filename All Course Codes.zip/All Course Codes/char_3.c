#include<stdio.h>
// printing a string
void main()
{
    // String is a character array which ends with letter 0
    // 0 is called as null terminator in C
    //char a[10] = {'W', 'e', 'l', ' ', 'c', 'o', 'm', 'e'};

    char a[20] = "Welcome to C Coding\n";
    printf("%s",a);
}
