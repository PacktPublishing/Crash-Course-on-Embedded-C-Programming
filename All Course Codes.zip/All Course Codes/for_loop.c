#include<stdio.h>

void main()
{
    int i;
    /*
    for(i = 0; i < 10; i++)
    {
        printf("\nHello World, how are you? value of i = %d\n",i);
    }*/

    for (i = 20; i > 10; i--)
    {
        printf("\nValue of i = %d\n", i);
    }
}
