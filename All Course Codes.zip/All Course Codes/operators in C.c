/*


*/
#include<stdio.h>
/*
void main()
{
    int a, b, c,d,e;
    a = 57;
    b = 41;
    c = 3;

    d = a / 5;
    printf("\n%d / 5 = %d\n", a, d);

    e = a % 5;

    printf(" 57/5, remainder of this division is %d\n\n", e);


}*/

void main()
{
    float a, b, c;
    float d;
    a = 57;
    b = 41;
    c = 3;

    d = a / 5;
    printf("division of 57/5 = %f", d);


}
